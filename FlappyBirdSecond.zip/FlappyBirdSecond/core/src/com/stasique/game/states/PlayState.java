package com.stasique.game.states;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Array;
import com.stasique.game.FlappyBird;

/**
 * Created by ceasefire on 01.12.2018.
 */
public class PlayState extends com.stasique.game.states.State {
    // расстояние между появляющимися трубами
    private static final int TUBE_SPACING = 125;
    // сколько труб вообще будет в игре
    private static final int TUBE_COUNT = 4;

    private static final int GROUND_Y_OFFSET = -50;

    private com.stasique.game.sprites.Bird bird;
    private Texture bg;
    private Texture ground;
    private Vector2 groundPos1, groundPos2;

    private Array<com.stasique.game.sprites.Tube> tubes;

    public PlayState(com.stasique.game.states.GameStateManager gsm) {
        // вызываем родительский конструктор
        super(gsm);
        // создаем экземпляр птицы
        bird = new com.stasique.game.sprites.Bird(50, 300);
        // ставим камеру
        cam.setToOrtho(false, FlappyBird.WIDTH / 2, FlappyBird.HEIGHT / 2);
        bg = new Texture("bg.png");
        ground = new Texture("ground.png");
        groundPos1 = new Vector2(cam.position.x - cam.viewportWidth / 2, GROUND_Y_OFFSET);
        groundPos2 = new Vector2((cam.position.x - cam.viewportWidth / 2) + ground.getWidth(), GROUND_Y_OFFSET);

        tubes = new Array<com.stasique.game.sprites.Tube>();

        // создаем трубы, пока количество труб не будет равно TUBE_COUNT
        for(int i = 1; i <= TUBE_COUNT; i++){
            tubes.add(new com.stasique.game.sprites.Tube(i * (TUBE_SPACING + com.stasique.game.sprites.Tube.TUBE_WIDTH)));
        }


    }

    @Override
    protected void handleInput() {
        // если было произведено нажатие на экран,
        // то птичка прыгает вверх
        if(Gdx.input.justTouched())
            bird.jump();
    }

    @Override
    public void update(float dt) {
        handleInput();
        updateGround();


        bird.update(dt);
        // камеру направляем ровно за птицей, не удаем птице улететь
        cam.position.x = bird.getPosition().x + 80;

        // заставляем трубы двигаться
        for(int i = 0; i < tubes.size; i++){
            com.stasique.game.sprites.Tube tube = tubes.get(i);

            if(cam.position.x - (cam.viewportWidth / 2) > tube.getPosTopTube().x + tube.getTopTube().getWidth()){
                tube.reposition(tube.getPosTopTube().x  + ((com.stasique.game.sprites.Tube.TUBE_WIDTH + TUBE_SPACING) * TUBE_COUNT));
            }

            // при обнаружении столкновений, игра перезагружается
            if(tube.collides(bird.getBounds()))
                gsm.set(new com.stasique.game.states.MenuState(gsm));
        }

        if(bird.getPosition().y <= ground.getHeight() + GROUND_Y_OFFSET)
            gsm.set(new com.stasique.game.states.MenuState(gsm));

        // обновление камеры
        cam.update();

    }

    @Override
    public void render(SpriteBatch sb) {
        sb.setProjectionMatrix(cam.combined);
        sb.begin();
        // отрисовка фона и отрисовка птички
        sb.draw(bg, cam.position.x - (cam.viewportWidth / 2), 0);
        sb.draw(bird.getTexture(), bird.getPosition().x, bird.getPosition().y);

        for(com.stasique.game.sprites.Tube tube : tubes) {
            sb.draw(tube.getTopTube(), tube.getPosTopTube().x, tube.getPosTopTube().y);
            sb.draw(tube.getBottomTube(), tube.getPosBotTube().x, tube.getPosBotTube().y);
        }

        sb.draw(ground, groundPos1.x, groundPos1.y);
        sb.draw(ground, groundPos2.x, groundPos2.y);
        sb.end();
    }

    @Override
    public void dispose() {
        bg.dispose();
        bird.dispose();
        ground.dispose();
        for(com.stasique.game.sprites.Tube tube : tubes)
            tube.dispose();
    }

    // метод для непрерывного отображения земли
    private void updateGround(){
        if(cam.position.x - (cam.viewportWidth / 2) > groundPos1.x + ground.getWidth())
            groundPos1.add(ground.getWidth() * 2, 0);
        if(cam.position.x - (cam.viewportWidth / 2) > groundPos2.x + ground.getWidth())
            groundPos2.add(ground.getWidth() * 2, 0);
    }
}
